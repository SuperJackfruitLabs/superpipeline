# vibekit

One design for every Super Jackfruit Labs product.

People choose a **vibe** (Daylight, Paper, Studio or Quiet). It sets how every product looks
and how its screens are laid out, in light and dark, with a room that follows the sun.

## Use it

```sh
npm install @superjackfruitlabs/vibekit-ui
```

See [docs/usage.md](docs/usage.md). Without Svelte (a server-rendered app such as Accounts): [docs/non-svelte.md](docs/non-svelte.md). Motion: [docs/motion.md](docs/motion.md). Agents: [static/llms.txt](static/llms.txt).

## Work on it

Scripts need Node 22.

```sh
corepack enable && pnpm install
pnpm dev          # the gallery at http://localhost:5173
pnpm tokens       # after editing tokens/source
pnpm verify       # everything CI checks
pnpm test:e2e     # screenshots, aria snapshots and axe
pnpm test:phone   # the phone-width suite (runs in CI)
pnpm storybook       # every component in every vibe, theme and accent, at http://localhost:6006
pnpm references      # rebuild the reference sheets from references/src (committed)
pnpm references:lock # record new sheets in references.lock; a changed sheet needs --allow <Component|pixels|sheet>
pnpm references:check # rebuild the sheets and fail if references/components differs from what is committed
pnpm test:stories    # each story's play function and its axe check, in Chromium
pnpm test:pixels     # each component's story against its reference sheets, 8 looks each (both sides rendered live; runs in CI)
```

Design sources: [design/mockups/](design/mockups/README.md) (open `design/mockups/index.html`); the Accounts artboards are in [design/mockups/accounts/](design/mockups/accounts/README.md).

Colours are edited only in `tokens/source/*.ts`, as hex. `tokens/dtcg` and `src/lib/styles/tokens.css` are generated, and are committed so changes are reviewable.

**Start here:** [the vibes design spec](docs/specs/2026-10-11-vibes-design.md).

## Releasing

A release is a `vX.Y.Z` tag on `main`, pushed by the operator. The tag reaches the GitHub mirror
through the push mirror, where the suite's shared release workflow (`.github/workflows/release.yml`,
synced from the release kit; do not edit it here) checks the forge CI result for the commit
(`ci / verify (push)`), runs `.github/release/check.sh` (package name, version equal to the tag,
the tag's `CHANGELOG.md` section), publishes `@superjackfruitlabs/vibekit-ui` to npm through
`.github/release/publish.sh`, and writes the GitHub release.

npm trusts the workflow through OIDC (trusted publishing, GitHub environment `npm`); no npm token
is stored anywhere. Before the first tag:

1. The package has to exist on npm before a trusted publisher can be added to it, so the first
   version is published by hand once (`npm publish --access public` from a clean checkout of the
   tag's commit, after `pnpm install --frozen-lockfile && pnpm package`).
2. On npmjs.com, the package's Settings → Trusted publishing → GitHub Actions: organisation
   `SuperJackfruitLabs`, repository `vibekit`, workflow `release.yml`, environment `npm`, and
   allow `npm publish` (not only staged publishing).
3. On the GitHub mirror, an environment `npm` whose deployment rule allows only `v*` tags.

Cutting a release: `sh .github/release/prep-release.sh vX.Y.Z` in a release-prep PR (it stamps
`## Unreleased`), bump `package.json` to the same version, merge, wait for forge CI, then the
operator tags the merge commit.
