# vibekit

One design for every Super Jackfruit Labs product.

People choose a **vibe** (Daylight, Paper, Studio or Quiet). It sets how every product looks
and how its screens are laid out, in light and dark, with a room that follows the sun.

## Use it

See [docs/usage.md](docs/usage.md). Agents: [static/llms.txt](static/llms.txt).

## Work on it

```sh
corepack enable && pnpm install
pnpm dev          # the gallery at http://localhost:5173
pnpm tokens       # after editing tokens/source
pnpm verify       # everything CI checks
pnpm test:e2e     # screenshots, aria snapshots and axe
```

Colours are edited only in `tokens/source/*.ts`, as hex. `tokens/dtcg` and `src/lib/styles/tokens.css` are generated, and are committed so changes are reviewable.

**Start here:** [the vibes design spec](docs/specs/2026-10-11-vibes-design.md).
